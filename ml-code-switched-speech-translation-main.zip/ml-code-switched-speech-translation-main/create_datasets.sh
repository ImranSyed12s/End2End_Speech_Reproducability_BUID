#!/bin/bash

#
# For licensing see accompanying LICENSE file.
# Copyright (C) 2022 Apple Inc. All Rights Reserved.
#

cd miami
bash setup_all.sh
cd ../fisher
bash setup_all.sh
cd ../
