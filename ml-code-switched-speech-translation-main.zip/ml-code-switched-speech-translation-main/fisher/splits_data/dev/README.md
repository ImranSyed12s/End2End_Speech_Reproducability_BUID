# Contents
This folder should contain these files gathered from `fisher-callhome-corpus` (see `../../readme.md`):
- `fisher_dev.en.0`
- `fisher_dev.en.1`
- `fisher_dev.en.2`
- `fisher_dev.en.3`
- `fisher_dev.es`
- `fisher_dev.yaml`