# Contents
This folder should contain these files gathered from `fisher-callhome-corpus` (see `../../readme.md`):
- `fisher_test.en.0`
- `fisher_test.en.1`
- `fisher_test.en.2`
- `fisher_test.en.3`
- `fisher_test.es`
- `fisher_test.yaml`