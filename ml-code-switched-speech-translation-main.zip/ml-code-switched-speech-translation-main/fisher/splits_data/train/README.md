# Contents
This folder should contain these files gathered from `fisher-callhome-corpus` (see `../../readme.md`):
- `fisher_train.en`
- `fisher_train.es`
- `fisher_train.yaml`